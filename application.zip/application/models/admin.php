<?php
class Admin extends Base_model {

	public $table='admin';
	function __construct()
	{   
	    parent::__construct();          
	}
}
?>