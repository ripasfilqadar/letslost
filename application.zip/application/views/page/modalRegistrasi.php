<div class="modal fade" tabindex="-1" role="dialog" id="modalRegistrasi">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Sign Up</h4>
      </div>
      <div class="modal-body">
      <?php include 'formRegistrasi.php';?>
    </div>
  </div>
</div>